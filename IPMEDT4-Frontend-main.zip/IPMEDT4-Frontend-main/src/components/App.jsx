import Navbar from "./layout/navbar";
import React from 'react';

function App() {
  return (
    <>
      <Navbar />
    </>
  );
}

export default App;
